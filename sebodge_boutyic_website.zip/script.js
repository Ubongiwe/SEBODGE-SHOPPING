function shopNow() {
    document.getElementById('shop').scrollIntoView({ behavior: 'smooth' });
}

function checkout() {
    alert('Proceeding to checkout! Payment integration coming soon.');
}
